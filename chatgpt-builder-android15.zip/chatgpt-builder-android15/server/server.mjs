import http from 'node:http';
import fs from 'node:fs/promises';
import path from 'node:path';
import crypto from 'node:crypto';
import { spawn } from 'node:child_process';
import { fileURLToPath } from 'node:url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const ROOT = path.resolve(process.env.WORK_ROOT ?? path.join(__dirname, 'jobs'));
const TEMPLATE = path.resolve(process.env.TEMPLATE_ROOT ?? path.join(__dirname, '..', 'builder-template'));
const PORT = Number(process.env.PORT ?? 8787);
const MODEL = process.env.OPENAI_MODEL ?? 'gpt-5.3-codex';
const MAX_RETRIES = 3;
const BUILD_TIMEOUT_MS = 10 * 60 * 1000;
const jobs = new Map();

if (!process.env.OPENAI_API_KEY) {
  console.error('Missing OPENAI_API_KEY');
}
await fs.mkdir(ROOT, { recursive: true });

function json(res, status, value) {
  const payload = JSON.stringify(value);
  res.writeHead(status, {
    'Content-Type': 'application/json; charset=utf-8',
    'Cache-Control': 'no-store'
  });
  res.end(payload);
}

async function readBody(req, maxBytes = 120_000) {
  const chunks = [];
  let size = 0;
  for await (const chunk of req) {
    size += chunk.length;
    if (size > maxBytes) throw new Error('Request body too large');
    chunks.push(chunk);
  }
  const raw = Buffer.concat(chunks).toString('utf8');
  return raw ? JSON.parse(raw) : {};
}

function safeSlug(value) {
  return value.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '').slice(0, 40) || 'app';
}

async function copyDir(src, dst) {
  await fs.cp(src, dst, { recursive: true, force: true });
}

async function walk(dir) {
  const out = [];
  async function visit(current) {
    for (const entry of await fs.readdir(current, { withFileTypes: true })) {
      const full = path.join(current, entry.name);
      if (entry.name === '.gradle' || entry.name === 'build') continue;
      if (entry.isDirectory()) await visit(full);
      else out.push(path.relative(dir, full).replaceAll(path.sep, '/'));
    }
  }
  await visit(dir);
  return out.sort();
}

async function loadTextFiles(dir, maxBytes = 180_000) {
  const files = await walk(dir);
  const result = {};
  let total = 0;
  for (const rel of files) {
    if (!/\.(java|xml|gradle|properties|kts|txt|md|json)$/.test(rel)) continue;
    const data = await fs.readFile(path.join(dir, rel), 'utf8');
    if (total + data.length > maxBytes) break;
    result[rel] = data;
    total += data.length;
  }
  return result;
}

function extractResponseText(payload) {
  if (typeof payload?.output_text === 'string' && payload.output_text.trim()) return payload.output_text;
  const chunks = [];
  for (const item of payload?.output ?? []) {
    for (const content of item?.content ?? []) {
      if (content?.type === 'output_text' && typeof content.text === 'string') chunks.push(content.text);
    }
  }
  return chunks.join('\n');
}

function extractJson(text) {
  const cleaned = text.trim().replace(/^```json\s*/i, '').replace(/```$/i, '').trim();
  const start = cleaned.indexOf('{');
  const end = cleaned.lastIndexOf('}');
  if (start < 0 || end <= start) throw new Error('Model did not return a JSON object');
  return JSON.parse(cleaned.slice(start, end + 1));
}

async function callOpenAI(messages) {
  if (!process.env.OPENAI_API_KEY) throw new Error('OPENAI_API_KEY is not configured');
  const response = await fetch('https://api.openai.com/v1/responses', {
    method: 'POST',
    headers: {
      'Authorization': `Bearer ${process.env.OPENAI_API_KEY}`,
      'Content-Type': 'application/json'
    },
    body: JSON.stringify({
      model: MODEL,
      input: messages
    })
  });
  const payload = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(payload?.error?.message ?? `OpenAI HTTP ${response.status}`);
  const text = extractResponseText(payload);
  if (!text) throw new Error('OpenAI response did not contain output text');
  return text;
}

const SYSTEM = `You are the source-generation agent for a private Android APK builder.
Return ONLY valid JSON with exactly: {"files":{"relative/path":"complete file contents"}}.

TARGET PLATFORM:
- Android 15 / API 35 compatibility is mandatory.
- compileSdk 35 and targetSdk 35 are already enforced by the protected Gradle template.
- Java 17 source/target is mandatory.
- The baseline template is Java/XML and must remain free of native .so dependencies.
- Do not add NDK/C++/Rust/native dependencies, custom JNI libraries, or SDKs that package native .so files.
- Android 15 enforces edge-to-edge for target 35. Preserve the existing MainActivity edge-to-edge/insets implementation whenever MainActivity is modified.
- Do not remove the root view id @+id/root from activity_main.xml when it exists.
- Apply window/system-bar/IME insets rather than relying on fitsSystemWindows.
- Avoid deprecated storage/file-path assumptions and broad external-storage permissions.

PROJECT RULES:
- You may change files only under app/src/main/ and app/src/test/.
- Do not edit settings.gradle, root build.gradle, app/build.gradle, gradle.properties, or any file outside app/src/main/ and app/src/test/.
- Do not add third-party Gradle dependencies. Use Android platform Java/XML APIs.
- Keep the app installable on Android 7.0+.
- Generate complete file contents, not diffs.
- Implement the user's product specification faithfully.
- Never put secrets, API keys, or private credentials into generated source code.
- For networking, use secure HTTPS by default unless the user's requested feature explicitly needs a local/dev HTTP endpoint.
- Keep permissions minimal and only add a permission when the requested feature genuinely needs it.`;

function isAllowedPath(rel) {
  const normalized = rel.replaceAll('\\', '/');
  return !path.isAbsolute(normalized)
    && !normalized.split('/').includes('..')
    && (normalized.startsWith('app/src/main/') || normalized.startsWith('app/src/test/'));
}

async function applyFiles(workspace, files) {
  for (const [rel, content] of Object.entries(files ?? {})) {
    if (typeof content !== 'string') throw new Error(`Invalid content for ${rel}`);
    const normalized = rel.replaceAll('\\', '/');
    if (!isAllowedPath(normalized)) throw new Error(`Model tried to edit a protected or unsafe path: ${normalized}`);
    const target = path.join(workspace, normalized);
    await fs.mkdir(path.dirname(target), { recursive: true });
    await fs.writeFile(target, content, 'utf8');
  }
}

async function generateFiles(spec, repairContext = '') {
  const current = await loadTextFiles(spec.workspace);
  const prompt = [
    { role: 'developer', content: SYSTEM },
    { role: 'user', content: `App name: ${spec.appName}\n\nProduct request:\n${spec.prompt}\n\n${repairContext}\n\nCurrent template files:\n${JSON.stringify(current)}` }
  ];
  const text = await callOpenAI(prompt);
  const data = extractJson(text);
  if (!data.files || typeof data.files !== 'object') throw new Error('Missing files object from model');
  await applyFiles(spec.workspace, data.files);
}

function run(command, args, cwd, timeoutMs = BUILD_TIMEOUT_MS) {
  return new Promise((resolve, reject) => {
    const child = spawn(command, args, { cwd, env: process.env, shell: false });
    let out = '';
    let err = '';
    const timer = setTimeout(() => {
      child.kill('SIGKILL');
      reject(new Error(`Command timed out after ${Math.round(timeoutMs / 1000)}s: ${command} ${args.join(' ')}`));
    }, timeoutMs);
    child.stdout.on('data', d => out += d.toString());
    child.stderr.on('data', d => err += d.toString());
    child.on('error', e => { clearTimeout(timer); reject(e); });
    child.on('close', code => {
      clearTimeout(timer);
      if (code === 0) resolve({ out, err });
      else reject(new Error(`Command failed (${code})\n${out}\n${err}`));
    });
  });
}

async function validateSource(workspace) {
  const gradle = await fs.readFile(path.join(workspace, 'app', 'build.gradle'), 'utf8');
  if (!/compileSdk\s+35/.test(gradle) || !/targetSdk\s+35/.test(gradle)) {
    throw new Error('Android 15 validation failed: compileSdk/targetSdk must remain 35.');
  }

  const mainActivityPath = path.join(workspace, 'app', 'src', 'main', 'java', 'com', 'builder', 'generatedapp', 'MainActivity.java');
  try {
    const main = await fs.readFile(mainActivityPath, 'utf8');
    if (!/setDecorFitsSystemWindows\s*\(\s*false\s*\)/.test(main) && !/SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN/.test(main)) {
      throw new Error('MainActivity must preserve Android 15 edge-to-edge/insets handling.');
    }
  } catch (e) {
    if (e.code === 'ENOENT') throw new Error('MainActivity.java is required in the protected Android 15 template package.');
    throw e;
  }
}

async function validateApk(apk, buildTools) {
  if (buildTools) {
    const zipalign = path.join(buildTools, 'zipalign');
    const apksigner = path.join(buildTools, 'apksigner');
    try {
      await fs.access(zipalign);
      await run(zipalign, ['-c', '-P', '16', '-v', '4', apk], path.dirname(apk), 60_000);
    } catch (e) {
      throw new Error(`APK 16-KB/package alignment validation failed: ${e.message}`);
    }
    try {
      await fs.access(apksigner);
      await run(apksigner, ['verify', '--verbose', apk], path.dirname(apk), 60_000);
    } catch (e) {
      throw new Error(`APK signature validation failed: ${e.message}`);
    }
  }

  try {
    const listing = (await run('unzip', ['-l', apk], path.dirname(apk), 60_000)).out;
    if (/lib\/[^\n]+\.so/.test(listing)) {
      throw new Error('Generated APK contains native .so libraries. Native dependencies are disabled in this Android-15 builder baseline because they require separate 16-KB ELF validation/rebuild.');
    }
  } catch (e) {
    throw e;
  }
}

async function buildJob(jobId, input) {
  const dir = path.join(ROOT, jobId);
  const workspace = path.join(dir, 'workspace');
  const job = jobs.get(jobId);
  job.status = 'generating';
  job.message = 'Preparing Android 15 project…';
  await fs.mkdir(dir, { recursive: true });
  await copyDir(TEMPLATE, workspace);

  for (let attempt = 1; attempt <= MAX_RETRIES; attempt++) {
    try {
      job.message = `Generating Android 15 source (attempt ${attempt}/${MAX_RETRIES})…`;
      await generateFiles({ workspace, appName: input.appName, prompt: input.prompt }, job.repairContext ?? '');
      job.status = 'validating';
      job.message = 'Validating Android 15 target and edge-to-edge requirements…';
      await validateSource(workspace);

      job.status = 'building';
      job.message = `Running Gradle Android 15 build (attempt ${attempt}/${MAX_RETRIES})…`;
      const { out, err } = await run('gradle', [':app:assembleDebug', '--no-daemon', '--stacktrace'], workspace);
      const apk = path.join(workspace, 'app', 'build', 'outputs', 'apk', 'debug', 'app-debug.apk');
      await fs.access(apk);
      const buildTools = process.env.ANDROID_BUILD_TOOLS ? path.resolve(process.env.ANDROID_BUILD_TOOLS) : '';
      await validateApk(apk, buildTools);

      const artifact = `${safeSlug(input.appName)}.apk`;
      await fs.copyFile(apk, path.join(dir, artifact));
      job.status = 'completed';
      job.message = 'Android 15 APK build completed and validated.';
      job.artifact = artifact;
      job.log = `${out}\n${err}`.slice(-24000);
      return;
    } catch (e) {
      const log = String(e.message ?? e).slice(-16000);
      if (attempt === MAX_RETRIES) {
        job.status = 'failed';
        job.message = log.slice(-7000);
        return;
      }
      job.status = 'repairing';
      job.message = `Build/validation failed; asking the code agent to repair it (attempt ${attempt + 1}/${MAX_RETRIES})…`;
      job.repairContext = `The previous attempt failed Android 15 validation or Gradle build. Repair source files only. Error:\n${log}`;
    }
  }
}

const server = http.createServer(async (req, res) => {
  try {
    const url = new URL(req.url, `http://${req.headers.host}`);
    if (req.method === 'GET' && url.pathname === '/health') {
      return json(res, 200, {
        ok: true,
        model: MODEL,
        androidTarget: 35,
        java: 17,
        nativeDependencies: 'disabled'
      });
    }

    if (req.method === 'POST' && url.pathname === '/api/build') {
      const body = await readBody(req);
      if (!body.appName || !body.prompt) return json(res, 400, { error: 'appName and prompt are required' });
      const appName = String(body.appName).trim().slice(0, 80);
      const prompt = String(body.prompt).trim().slice(0, 30_000);
      if (!appName || !prompt) return json(res, 400, { error: 'appName and prompt are required' });
      const jobId = crypto.randomUUID();
      jobs.set(jobId, { status: 'queued', message: 'Queued.', createdAt: new Date().toISOString() });
      buildJob(jobId, { appName, prompt }).catch(err => {
        const job = jobs.get(jobId);
        if (job) { job.status = 'failed'; job.message = String(err.message ?? err).slice(-7000); }
      });
      return json(res, 202, { jobId });
    }

    const jobMatch = url.pathname.match(/^\/api\/jobs\/([0-9a-f-]+)$/i);
    if (req.method === 'GET' && jobMatch) {
      const job = jobs.get(jobMatch[1]);
      if (!job) return json(res, 404, { error: 'Unknown job' });
      return json(res, 200, job);
    }

    const artifactMatch = url.pathname.match(/^\/api\/artifacts\/([0-9a-f-]+)$/i);
    if (req.method === 'GET' && artifactMatch) {
      const jobId = artifactMatch[1];
      const job = jobs.get(jobId);
      if (!job || job.status !== 'completed') return json(res, 404, { error: 'Artifact not ready' });
      const filePath = path.join(ROOT, jobId, job.artifact);
      const data = await fs.readFile(filePath);
      res.writeHead(200, {
        'Content-Type': 'application/vnd.android.package-archive',
        'Content-Length': data.length,
        'Content-Disposition': `attachment; filename="${job.artifact}"`,
        'Cache-Control': 'no-store'
      });
      return res.end(data);
    }

    json(res, 404, { error: 'Not found' });
  } catch (err) {
    json(res, 500, { error: String(err.message ?? err) });
  }
});

server.listen(PORT, '0.0.0.0', () => {
  console.log(`ChatGPT Builder Android 15 server listening on http://0.0.0.0:${PORT}`);
});
