# ChatGPT Builder — Android 15 backend

This backend receives a natural-language app request, asks an OpenAI coding model to generate Android Java/XML source, validates the Android 15 baseline, runs a Gradle build, checks APK alignment/signing, and returns the APK artifact.

## Android 15 build contract

The protected template enforces:

- compileSdk 35
- targetSdk 35
- minSdk 24
- Java 17
- Android 15 edge-to-edge/insets handling in the baseline activity
- no native `.so` dependencies in the baseline builder

Generated source may only edit `app/src/main/**` or `app/src/test/**`. Build configuration and dependency files are protected from the model.

## Requirements

- Linux
- Node.js 20+
- Java 17+
- Gradle 8.13+
- Android SDK Platform 35
- Android Build-Tools 35.0.0
- `zipalign`, `apksigner`, and `unzip` available to the server
- OpenAI API key stored only on the server

Set:

```text
OPENAI_API_KEY=...
OPENAI_MODEL=gpt-5.3-codex
PORT=8787
WORK_ROOT=./jobs
ANDROID_BUILD_TOOLS=$ANDROID_SDK_ROOT/build-tools/35.0.0
```

Start:

```bash
node server.mjs
```

## API

- `GET /health`
- `POST /api/build` with `{ "appName": "...", "prompt": "..." }`
- `GET /api/jobs/<job-id>`
- `GET /api/artifacts/<job-id>`

## Security

The server executes Gradle builds of model-generated application source. Keep it private, authenticate it, rate-limit it, and run it in an isolated Linux account/container. Never put the OpenAI API key in the Android APK.

For production use, expose the backend over HTTPS. The Android Builder client allows HTTP for local development, but the generated app baseline defaults to cleartext traffic disabled.
