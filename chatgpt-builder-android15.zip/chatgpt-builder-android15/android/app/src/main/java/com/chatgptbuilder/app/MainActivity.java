package com.chatgptbuilder.app;

import android.app.Activity;
import android.app.DownloadManager;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.text.TextUtils;
import android.view.View;
import android.view.Window;
import android.view.WindowInsets;
import android.view.WindowInsetsController;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;

import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {
    private static final String PREFS = "builder_prefs";
    private static final String KEY_BACKEND = "backend_url";

    private EditText appName;
    private EditText prompt;
    private EditText backendUrl;
    private TextView status;
    private ProgressBar progress;
    private Button buildButton;
    private Button healthButton;
    private Button downloadButton;
    private String lastArtifactUrl;
    private String lastArtifactName = "generated-app.apk";
    private final ExecutorService executor = Executors.newSingleThreadExecutor();
    private final Handler mainHandler = new Handler(Looper.getMainLooper());

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        configureAndroid15EdgeToEdge();

        appName = findViewById(R.id.appName);
        prompt = findViewById(R.id.prompt);
        backendUrl = findViewById(R.id.backendUrl);
        status = findViewById(R.id.status);
        progress = findViewById(R.id.progress);
        buildButton = findViewById(R.id.buildButton);
        healthButton = findViewById(R.id.healthButton);
        downloadButton = findViewById(R.id.downloadButton);

        SharedPreferences prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        backendUrl.setText(prefs.getString(KEY_BACKEND, ""));

        buildButton.setOnClickListener(v -> startBuild());
        healthButton.setOnClickListener(v -> checkHealth());
        downloadButton.setOnClickListener(v -> downloadArtifact());
    }

    /**
     * Android 15 (API 35) enforces edge-to-edge for apps targeting 35+.
     * We apply system-bar + IME insets ourselves so controls aren't hidden.
     */
    private void configureAndroid15EdgeToEdge() {
        final Window window = getWindow();
        if (Build.VERSION.SDK_INT >= 30) {
            window.setDecorFitsSystemWindows(false);
        } else {
            window.getDecorView().setSystemUiVisibility(
                    View.SYSTEM_UI_FLAG_LAYOUT_STABLE |
                    View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN |
                    View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION);
        }

        if (Build.VERSION.SDK_INT >= 23) {
            window.getDecorView().setSystemUiVisibility(
                    window.getDecorView().getSystemUiVisibility() |
                    View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);
        }
        if (Build.VERSION.SDK_INT >= 29) {
            window.setNavigationBarContrastEnforced(false);
            window.setStatusBarContrastEnforced(false);
        }

        final View root = findViewById(R.id.root);
        final int left = root.getPaddingLeft();
        final int top = root.getPaddingTop();
        final int right = root.getPaddingRight();
        final int bottom = root.getPaddingBottom();

        root.setOnApplyWindowInsetsListener((v, insets) -> {
            int topInset = 0;
            int bottomInset = 0;
            int leftInset = 0;
            int rightInset = 0;
            if (Build.VERSION.SDK_INT >= 30) {
                WindowInsets.Type type = null;
                android.graphics.Insets bars = insets.getInsets(WindowInsets.Type.systemBars());
                android.graphics.Insets ime = insets.getInsets(WindowInsets.Type.ime());
                topInset = bars.top;
                leftInset = bars.left;
                rightInset = bars.right;
                bottomInset = Math.max(bars.bottom, ime.bottom);
            } else {
                topInset = insets.getSystemWindowInsetTop();
                bottomInset = Math.max(insets.getSystemWindowInsetBottom(), 0);
                leftInset = insets.getSystemWindowInsetLeft();
                rightInset = insets.getSystemWindowInsetRight();
            }
            v.setPadding(left + leftInset, top + topInset, right + rightInset, bottom + bottomInset);
            return insets;
        });
        root.requestApplyInsets();
    }

    private void startBuild() {
        String name = appName.getText().toString().trim();
        String userPrompt = prompt.getText().toString().trim();
        String backend = normalizeBackend(backendUrl.getText().toString().trim());

        if (TextUtils.isEmpty(name) || TextUtils.isEmpty(userPrompt) || TextUtils.isEmpty(backend)) {
            status.setText("Enter an app name, app description, and builder backend URL.");
            return;
        }
        if (!isHttpUrl(backend)) {
            status.setText("Backend URL must start with http:// or https://.");
            return;
        }

        getSharedPreferences(PREFS, MODE_PRIVATE)
                .edit().putString(KEY_BACKEND, backend).apply();

        setBusy(true, "Submitting build request…");
        final String finalBackend = backend;
        executor.execute(() -> {
            try {
                JSONObject body = new JSONObject();
                body.put("appName", name);
                body.put("prompt", userPrompt);
                JSONObject response = postJson(finalBackend + "/api/build", body);
                String jobId = response.optString("jobId", "");
                if (jobId.isEmpty()) throw new IllegalStateException("Backend did not return a job ID.");
                pollJob(finalBackend, jobId);
            } catch (Exception e) {
                showFailure("Build failed: " + cleanMessage(e));
            }
        });
    }

    private void checkHealth() {
        String backend = normalizeBackend(backendUrl.getText().toString().trim());
        if (!isHttpUrl(backend)) {
            status.setText("Enter a valid builder backend URL first.");
            return;
        }
        setBusy(true, "Checking builder backend…");
        final String finalBackend = backend;
        executor.execute(() -> {
            try {
                JSONObject response = getJson(finalBackend + "/health");
                showStatus("Backend is online. Model: " + response.optString("model", "configured"));
                mainHandler.post(() -> setBusy(false, null));
            } catch (Exception e) {
                showFailure("Health check failed: " + cleanMessage(e));
            }
        });
    }

    private void pollJob(String backend, String jobId) throws Exception {
        for (int i = 0; i < 180; i++) {
            JSONObject response = getJson(backend + "/api/jobs/" + jobId);
            String state = response.optString("status", "unknown");
            String message = response.optString("message", "");
            showStatus(state + "\n" + message);

            if ("completed".equals(state)) {
                lastArtifactUrl = backend + "/api/artifacts/" + jobId;
                lastArtifactName = response.optString("artifact", "generated-app.apk");
                mainHandler.post(() -> {
                    progress.setIndeterminate(false);
                    progress.setProgress(100);
                    buildButton.setEnabled(true);
                    healthButton.setEnabled(true);
                    downloadButton.setEnabled(true);
                    status.setText("APK ready. Tap DOWNLOAD APK to save it.");
                });
                return;
            }
            if ("failed".equals(state)) {
                throw new IllegalStateException(message.isEmpty() ? "Unknown build error." : message);
            }
            Thread.sleep(2500L);
        }
        throw new IllegalStateException("Timed out waiting for the builder (15 minutes).");
    }

    private void downloadArtifact() {
        if (lastArtifactUrl == null) {
            status.setText("No APK is ready yet.");
            return;
        }
        try {
            DownloadManager manager = (DownloadManager) getSystemService(Context.DOWNLOAD_SERVICE);
            DownloadManager.Request request = new DownloadManager.Request(Uri.parse(lastArtifactUrl));
            request.setTitle(lastArtifactName);
            request.setDescription("ChatGPT Builder APK");
            request.setMimeType("application/vnd.android.package-archive");
            request.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
            request.setDestinationInExternalPublicDir("Download", lastArtifactName);
            manager.enqueue(request);
            status.setText("Download started. Check your Downloads folder.");
        } catch (Exception e) {
            status.setText("Download failed: " + cleanMessage(e));
        }
    }

    private JSONObject postJson(String urlString, JSONObject body) throws Exception {
        HttpURLConnection connection = null;
        try {
            connection = (HttpURLConnection) new URL(urlString).openConnection();
            connection.setRequestMethod("POST");
            connection.setConnectTimeout(15000);
            connection.setReadTimeout(30000);
            connection.setRequestProperty("Content-Type", "application/json; charset=utf-8");
            connection.setRequestProperty("Accept", "application/json");
            connection.setDoOutput(true);
            try (OutputStream out = connection.getOutputStream()) {
                out.write(body.toString().getBytes(StandardCharsets.UTF_8));
            }
            return readJson(connection);
        } finally {
            if (connection != null) connection.disconnect();
        }
    }

    private JSONObject getJson(String urlString) throws Exception {
        HttpURLConnection connection = null;
        try {
            connection = (HttpURLConnection) new URL(urlString).openConnection();
            connection.setRequestMethod("GET");
            connection.setConnectTimeout(15000);
            connection.setReadTimeout(30000);
            connection.setRequestProperty("Accept", "application/json");
            return readJson(connection);
        } finally {
            if (connection != null) connection.disconnect();
        }
    }

    private JSONObject readJson(HttpURLConnection connection) throws Exception {
        int code = connection.getResponseCode();
        InputStream stream = code >= 400 ? connection.getErrorStream() : connection.getInputStream();
        if (stream == null) throw new IllegalStateException("HTTP " + code);
        StringBuilder text = new StringBuilder();
        try (BufferedReader reader = new BufferedReader(new InputStreamReader(stream, StandardCharsets.UTF_8))) {
            String line;
            while ((line = reader.readLine()) != null) text.append(line);
        }
        JSONObject json = new JSONObject(text.toString());
        if (code >= 400) throw new IllegalStateException(json.optString("error", "HTTP " + code));
        return json;
    }

    private String normalizeBackend(String value) {
        return value.replaceAll("/+$", "");
    }

    private boolean isHttpUrl(String value) {
        return value.startsWith("https://") || value.startsWith("http://");
    }

    private void setBusy(boolean busy, String message) {
        buildButton.setEnabled(!busy);
        healthButton.setEnabled(!busy);
        if (busy) {
            progress.setVisibility(View.VISIBLE);
            progress.setIndeterminate(true);
        } else {
            progress.setVisibility(View.GONE);
        }
        if (message != null) status.setText(message);
        if (busy) downloadButton.setEnabled(false);
    }

    private void showStatus(String message) {
        mainHandler.post(() -> status.setText(message));
    }

    private void showFailure(String message) {
        mainHandler.post(() -> {
            setBusy(false, message);
            buildButton.setEnabled(true);
            healthButton.setEnabled(true);
        });
    }

    private String cleanMessage(Exception e) {
        String message = e.getMessage();
        return message == null || message.isEmpty() ? e.getClass().getSimpleName() : message;
    }

    @Override
    protected void onDestroy() {
        executor.shutdownNow();
        mainHandler.removeCallbacksAndMessages(null);
        super.onDestroy();
    }
}
