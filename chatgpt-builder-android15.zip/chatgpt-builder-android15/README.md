# ChatGPT Builder — Android 15 rebuild

This is the rebuilt version of the ChatGPT Builder prototype, updated specifically for Android 15 / API 35.

## What changed

- Android client and generated-app template both target **API 35**.
- Java 17 is enforced.
- Android 15 edge-to-edge/insets handling is built into the client and generated-app baseline.
- Generated projects are kept Java/XML-only by default so they do not accidentally ship native `.so` libraries that would need separate 16-KB ELF validation.
- The backend validates target/compile SDK, preserves the edge-to-edge baseline activity, builds with Gradle, checks APK alignment with `zipalign -P 16`, verifies the APK signature, and rejects native `.so` libraries in this baseline.
- The Android Builder app now has a server health check, saved backend URL, build progress, and a real Download APK action using Android's `DownloadManager`.
- The OpenAI API key remains server-side.

## Architecture

`Android 15 Builder APK → private backend → OpenAI Responses API → generated Java/XML → Gradle → validated APK`

## Important

This is an unofficial builder application; it is not the official OpenAI ChatGPT Android app.

API 35 is the Android 15 target requested here. For Google Play submissions after August 31, 2026, Google requires new apps and updates to target Android 16 / API 36 or higher (with platform-specific exceptions), so a Play-ready version should later move to API 36. See the official Android documentation for current Play requirements.
